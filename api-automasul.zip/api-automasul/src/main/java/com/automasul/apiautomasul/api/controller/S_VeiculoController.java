package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.S_Veiculo;
import com.automasul.apiautomasul.model.StatusSolicitacao;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.S_VeiculoRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/sveiculo")
public class S_VeiculoController {
    @Autowired
    private S_VeiculoRepository sVeiculoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<S_Veiculo> sVeiculos = sVeiculoRepository.findAll();

        if (sVeiculos.isEmpty()) {
            return ResponseEntity.ok("Nenhuma solicitação de veículo encontrada.");
        }

        return ResponseEntity.ok(sVeiculos);
    }

    @GetMapping("/{sveiculoID}")
    private ResponseEntity<?> findByID(@PathVariable String sveiculoID){
        Optional<S_Veiculo> sVeiculoOptional =
                sVeiculoRepository.findById(sveiculoID);

        if (sVeiculoOptional.isEmpty()) {
            return ResponseEntity.ok("Solicitação de veículo não encontrada.");
        }

        return ResponseEntity.ok(sVeiculoOptional.get());
    }

    @GetMapping("/statussolicitacao/{statusSolicitacao}")
    private ResponseEntity<?> findByStatus(@PathVariable StatusSolicitacao statusSolicitacao){
        List<S_Veiculo> sVeiculos =
                sVeiculoRepository.findAllByStatusSolicitacao(statusSolicitacao);

        if (sVeiculos.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + statusSolicitacao.name() + " " +
                    "em solicitação de veículo encontrado.");
        }

        return ResponseEntity.ok(sVeiculos);
    }

    @PutMapping("/{sveiculoID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String sveiculoID,
            @PathVariable String usuarioID,
            @RequestBody S_Veiculo sVeiculo) {
        Optional<S_Veiculo> sVeiculoOptional =
                sVeiculoRepository.findById(sveiculoID);

        if (sVeiculoOptional.isPresent()) {
            S_Veiculo sVeiculoCurrent = sVeiculoOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()) {
                Usuario usuarioCurrent = usuarioOptional.get();

                BeanUtils.copyProperties(sVeiculo, sVeiculoCurrent,
                        "id", "projeto", "controleUsuario",
                        "destino", "tipo", "saida", "retorno", "passageiros", "qtdPassageiros");

                sVeiculoCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                sVeiculoRepository.save(sVeiculoCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody S_Veiculo sVeiculo) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            sVeiculo.getControleUsuario().prePersist(usuarioCurrent.getId());
            sVeiculo.prePersist(sVeiculo.getPassageiros());
            sVeiculoRepository.save(sVeiculo);

            return ResponseEntity.ok("Solicitação para veículo cadastrada com sucesso.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

}
