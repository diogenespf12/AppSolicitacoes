package com.automasul.apiautomasul.model;

public enum StatusSolicitacao {
    NAO_ATENDIDA,
    EM_ANDAMENTO,
    ATENDIDA
}
