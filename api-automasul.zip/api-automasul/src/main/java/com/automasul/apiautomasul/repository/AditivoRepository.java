package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.Aditivo;
import com.automasul.apiautomasul.model.TipoContrato;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AditivoRepository extends MongoRepository<Aditivo, String> {
    List<Aditivo> findAllByTipoContrato(TipoContrato tipoContrato);
    List<Aditivo> findAllByAtivo(Boolean ativo);
}
