package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.Finalidade;
import com.automasul.apiautomasul.model.Tipo;
import com.automasul.apiautomasul.repository.TipoRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tipo")
public class TipoController {
    @Autowired
    private TipoRepository tipoRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<Tipo> tipos = tipoRepository.findAll();

        if (tipos.isEmpty()) {
            return ResponseEntity.ok("Nenhum tipo encontrado.");
        }

        return ResponseEntity.ok(tipos);
    }

    @GetMapping("/finalidade/{finalidade}")
    private ResponseEntity<?> findAllFinalidade(@PathVariable Finalidade finalidade) {
        List<Tipo> tipos = tipoRepository.findAllByFinalidade(finalidade);

        if (tipos.isEmpty()) {
            return ResponseEntity.ok("Nenhuma finalidade: " + finalidade.name() + " em tipo foi encontrada.");
        }

        return ResponseEntity.ok(tipos);
    }

    @GetMapping("/{tipoID}")
    private ResponseEntity<?> findByID(@PathVariable String tipoID){
        Optional<Tipo> tipoOptional = tipoRepository.findById(tipoID);

        if (tipoOptional.isEmpty()) {
            return ResponseEntity.ok("Tipo não encontrado.");
        }

        return ResponseEntity.ok(tipoOptional.get());
    }

    @GetMapping("/nome/{nome}")
    private ResponseEntity<?> findByNome(@PathVariable String nome){
        Optional<Tipo> tipoOptional = tipoRepository.findByNome(nome);

        if (tipoOptional.isEmpty()) {
            return ResponseEntity.ok("Tipo não encontrado.");
        }

        return ResponseEntity.ok(tipoOptional.get());
    }

    @PutMapping("/{tipoID}")
    public ResponseEntity<?> update(
            @PathVariable String tipoID,
            @RequestBody Tipo tipo) {
        Optional<Tipo> tipoOptional = tipoRepository.findById(tipoID);

        if (tipoOptional.isPresent()) {
            Tipo tipoCurrent = tipoOptional.get();

            Optional<Tipo> tipoExistenteOptional = tipoRepository.findByNomeAndFinalidade(tipo.getNome(), tipo.getFinalidade());

            if (tipoExistenteOptional.isPresent() && !tipoExistenteOptional.get().getId().equals(tipoID)) {
                return ResponseEntity.badRequest().body("O nome já está em uso para a mesma finalidade.");
            }

            BeanUtils.copyProperties(tipo, tipoCurrent, "id");

            tipoRepository.save(tipoCurrent);
            return ResponseEntity.ok("Dados atualizados.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@RequestBody Tipo tipo) {
        Optional<Tipo> tipoExistenteOptional = tipoRepository.findByNomeAndFinalidade(tipo.getNome(), tipo.getFinalidade());

        if (tipoExistenteOptional.isPresent()) {
            return ResponseEntity.badRequest().body("Já existe um tipo com o mesmo nome e finalidade.");
        } else {
            tipoRepository.save(tipo);
            return ResponseEntity.ok("Tipo cadastrado com sucesso.");
        }
    }

}
