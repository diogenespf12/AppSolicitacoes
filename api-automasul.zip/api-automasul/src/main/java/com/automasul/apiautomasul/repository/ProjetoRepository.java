package com.automasul.apiautomasul.repository;
import com.automasul.apiautomasul.model.Projeto;
import com.automasul.apiautomasul.model.TipoContrato;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface ProjetoRepository extends MongoRepository<Projeto, String> {
    Optional<Projeto> findByNumero(Integer numero);
    List<Projeto> findAllByTipoContrato(TipoContrato tipoContrato);
    List<Projeto> findAllByAtivo(Boolean ativo);
}
