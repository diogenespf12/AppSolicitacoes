package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class S_Equipamento extends Solicitacao{
    @DBRef
    private List<FerramentaEquipamento> equipamentos;
    private Boolean proprio;
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private String descricaoUso;
}
