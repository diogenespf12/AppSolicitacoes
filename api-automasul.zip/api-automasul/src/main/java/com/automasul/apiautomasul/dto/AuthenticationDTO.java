package com.automasul.apiautomasul.dto;

public record AuthenticationDTO  (String login, String senha){
}
