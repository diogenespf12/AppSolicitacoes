package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.Status;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.model.Veiculo;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import com.automasul.apiautomasul.repository.VeiculoRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/veiculo")
public class VeiculoController {
    @Autowired
    private VeiculoRepository veiculoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<Veiculo> veiculos = veiculoRepository.findAll();

        if (veiculos.isEmpty()) {
            return ResponseEntity.ok("Nenhum veículo encontrado.");
        }

        return ResponseEntity.ok(veiculos);
    }

    @GetMapping("/{veiculoID}")
    private ResponseEntity<?> findByID(@PathVariable String veiculoID){
        Optional<Veiculo> veiculoOptional = veiculoRepository.findById(veiculoID);

        if (veiculoOptional.isEmpty()) {
            return ResponseEntity.ok("Veículo não encontrado.");
        }

        return ResponseEntity.ok(veiculoOptional.get());
    }

    @GetMapping("/placa/{placa}")
    private ResponseEntity<?> findByPlaca(@PathVariable String placa){
        Optional<Veiculo> veiculoOptional = veiculoRepository.findByPlaca(placa);

        if (veiculoOptional.isEmpty()) {
            return ResponseEntity.ok("Veículo não encontrado.");
        }

        return ResponseEntity.ok(veiculoOptional.get());
    }

    @GetMapping("/status/{status}")
    private ResponseEntity<?> findByStatus(@PathVariable Status status){
        List<Veiculo> veiculos = veiculoRepository.findAllByStatus(status);

        if (veiculos.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + status.name() + " em veículo foi encontrado.");
        }

        return ResponseEntity.ok(veiculos);
    }

    @PutMapping("/{veiculoID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String veiculoID,
            @PathVariable String usuarioID,
            @RequestBody Veiculo veiculo) {
        Optional<Veiculo> veiculoOptional = veiculoRepository.findById(veiculoID);

        if (veiculoOptional.isPresent()){
            Veiculo veiculoCurrent = veiculoOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()){
                Usuario usuarioCurrent = usuarioOptional.get();

                Optional<Veiculo> veiculoExistenteOptional = veiculoRepository.findByPlaca(veiculo.getPlaca());

                if (veiculoExistenteOptional.isPresent() && !veiculoExistenteOptional.get().getId().equals(veiculoID)) {
                    return ResponseEntity.badRequest().body("A placa já está em uso.");
                }

                BeanUtils.copyProperties(veiculo, veiculoCurrent, "id", "controleUsuario");

                veiculoCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                veiculoRepository.save(veiculoCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody Veiculo veiculo) {
        if (veiculoRepository.findByPlaca(veiculo.getPlaca()).isPresent()) {
            return ResponseEntity.badRequest().body("Veículo já existe.");
        }
        else {
            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()){
                Usuario usuarioCurrent = usuarioOptional.get();

                veiculo.getControleUsuario().prePersist(usuarioCurrent.getId());
                veiculoRepository.save(veiculo);
                return ResponseEntity.ok("Veículo cadastrado com sucesso.");
            }
            return ResponseEntity.badRequest().body("Dados inválidos.");
        }
    }

}
