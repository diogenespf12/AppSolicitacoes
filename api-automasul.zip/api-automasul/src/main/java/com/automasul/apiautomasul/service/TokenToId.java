package com.automasul.apiautomasul.service;

import com.automasul.apiautomasul.model.Usuario;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class TokenToId {
    public String extractToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }

    public String getUserIdFromUserDetails(UserDetails userDetails) {

        if (userDetails instanceof Usuario) {
            Usuario usuario = (Usuario) userDetails;
            return usuario.getId();
        }
        return null;
    }
}
