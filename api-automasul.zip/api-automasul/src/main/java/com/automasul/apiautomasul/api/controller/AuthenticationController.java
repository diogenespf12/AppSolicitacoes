package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.dto.AuthenticationDTO;
import com.automasul.apiautomasul.dto.LoginResponseDTO;
import com.automasul.apiautomasul.dto.RegisterDTO;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import com.automasul.apiautomasul.service.TokenService;
import com.automasul.apiautomasul.service.TokenToId;
import com.automasul.apiautomasul.service.UserDetailsServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthenticationController {
    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private TokenToId tokenToId;

    @GetMapping("/id/")
    public ResponseEntity<?> getUserId(HttpServletRequest httpServletRequest) {
        String token = tokenToId.extractToken(httpServletRequest);
        if (token != null) {
            var login = tokenService.validateToken(token);
            if (!login.isEmpty()) {
                UserDetails userDetails = userDetailsServiceImpl.loadUserByUsername(login);
                if (userDetails != null) {
                    String userId = tokenToId.getUserIdFromUserDetails(userDetails);
                    return ResponseEntity.ok(userId);
               }
            }
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @PostMapping("/login/")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<?> login(@RequestBody AuthenticationDTO authenticationDTO){
        var usernamePassword = new UsernamePasswordAuthenticationToken(
                authenticationDTO.login(),
                authenticationDTO.senha());
        var authentication = authenticationManager.authenticate(usernamePassword);

        var token = tokenService.generateToken((Usuario) authentication.getPrincipal());
        return ResponseEntity.ok(new LoginResponseDTO(token));
    }

    @PostMapping("/register/")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> register(@RequestBody RegisterDTO registerDTO){
        if (userDetailsServiceImpl.loadUserByUsername(registerDTO.login())
        != null){
            return ResponseEntity.badRequest().body("Usuário já existe.");
        }
        String passwordEncrypted = new BCryptPasswordEncoder()
                .encode(registerDTO.senha());
        Usuario usuario = new Usuario(
                registerDTO.role(),
                registerDTO.login(),
                passwordEncrypted,
                registerDTO.contato());
        usuarioRepository.save(usuario);
        return ResponseEntity.ok("Conta criada com sucesso.");
    }
}
