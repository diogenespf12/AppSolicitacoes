package com.automasul.apiautomasul.model;

public enum Deslocamento {
    KM_RODADO,
    HR_DESLOCAMENTO
}
