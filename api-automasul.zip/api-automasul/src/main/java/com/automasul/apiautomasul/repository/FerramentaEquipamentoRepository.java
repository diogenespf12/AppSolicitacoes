package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.FerramentaEquipamento;
import com.automasul.apiautomasul.model.Status;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FerramentaEquipamentoRepository extends MongoRepository<FerramentaEquipamento, String> {
    Optional<FerramentaEquipamento> findByCodigo(String codigo);
    List<FerramentaEquipamento> findAllByStatus(Status status);
    List<FerramentaEquipamento> findAllByFerramenta(Boolean ferramenta);
    List<FerramentaEquipamento> findAllByFerramentaAndStatus(Boolean ferramenta, Status status);
    Optional<FerramentaEquipamento> findByFerramentaAndCodigo(Boolean ferramenta, String codigo);
}
