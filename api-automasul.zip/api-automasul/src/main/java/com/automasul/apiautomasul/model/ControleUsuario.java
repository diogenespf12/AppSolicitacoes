package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ControleUsuario {
    private LocalDate dataCadastrada;
    private String idUsuarioCadastrou;
    private LocalDate dataUltimaAtualizacao;
    private String idUsuarioAtualizou;

    public void prePersist(String id) {
        this.setDataCadastrada(LocalDate.now());
        this.setIdUsuarioCadastrou(id);
        this.setDataUltimaAtualizacao(LocalDate.now());
        this.setIdUsuarioAtualizou(id);
    }

    public void preUpdate(String id) {
        this.setDataUltimaAtualizacao(LocalDate.now());
        this.setIdUsuarioAtualizou(id);
    }
}
