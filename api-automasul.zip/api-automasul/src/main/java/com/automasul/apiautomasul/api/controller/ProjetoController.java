package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.*;
import com.automasul.apiautomasul.repository.AditivoRepository;
import com.automasul.apiautomasul.repository.ProjetoRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/projeto")
public class ProjetoController {
    @Autowired
    private ProjetoRepository projetoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private AditivoRepository aditivoRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<Projeto> projetos = projetoRepository.findAll();

        if (projetos.isEmpty()) {
            return ResponseEntity.ok("Nenhum projeto encontrado.");
        }

        return ResponseEntity.ok(projetos);
    }

    @GetMapping("/{projetoID}")
    private ResponseEntity<?> findByID(@PathVariable String projetoID){
        Optional<Projeto> projetoOptional = projetoRepository.findById(projetoID);

        if (projetoOptional.isEmpty()) {
            return ResponseEntity.ok("Projeto não encontrado.");
        }

        return ResponseEntity.ok(projetoOptional.get());
    }

    @GetMapping("/numero/{numero}")
    private ResponseEntity<?> findByNumero(@PathVariable Integer numero){
        Optional<Projeto> projetoOptional = projetoRepository.findByNumero(numero);

        if (projetoOptional.isEmpty()) {
            return ResponseEntity.ok("Projeto não encontrado.");
        }

        return ResponseEntity.ok(projetoOptional.get());
    }

    @GetMapping("/tipocontrato/{tipoContrato}")
    private ResponseEntity<?> findByTipoContrato(@PathVariable TipoContrato tipoContrato){
        List<Projeto> projetos = projetoRepository.findAllByTipoContrato(tipoContrato);

        if (projetos.isEmpty()) {
            return ResponseEntity.ok("Nenhum tipo de contrato: "
                    + tipoContrato.name()
                    + " em projeto foi encontrado.");
        }

        return ResponseEntity.ok(projetos);
    }

    @GetMapping("/ativo/{ativo}")
    private ResponseEntity<?> findByAtivo(@PathVariable Boolean ativo){
        List<Projeto> projetos = projetoRepository.findAllByAtivo(ativo);

        if (projetos.isEmpty()) {
            String mensagem;
            if (ativo) {
                mensagem = "Nenhum contrato ativo em projeto foi encontrado.";
            } else {
                mensagem = "Nenhum contrato inativo em projeto foi encontrado.";
            }
            return ResponseEntity.ok(mensagem);
        }

        return ResponseEntity.ok(projetos);
    }

    @GetMapping("/arquivo/conteudo/{projetoID}")
    public ResponseEntity<?> getArquivoConteudo(@PathVariable String projetoID) {
        Optional<Projeto> projetoOptional = projetoRepository.findById(projetoID);

        if (projetoOptional.isPresent()) {
            Projeto projeto = projetoOptional.get();
            Arquivo arquivo = projeto.getArquivo();

            if (arquivo != null && arquivo.getDados() != null && arquivo.getDados().length > 0) {
                String conteudo = new String(arquivo.getDados(), StandardCharsets.UTF_8);
                return ResponseEntity.ok(conteudo);
            } else {
                return ResponseEntity.ok("Não há conteúdo no arquivo.");
            }
        } else {
            return ResponseEntity.badRequest().body("Projeto não encontrado.");
        }
    }

    @PutMapping("/{projetoID}")
    public ResponseEntity<?> updateProjeto(
            @PathVariable String projetoID,
            @RequestBody Projeto projeto) {
        Optional<Projeto> projetoOptional = projetoRepository.findById(projetoID);

        if (projetoOptional.isPresent()) {
            Projeto projetoCurrent = projetoOptional.get();

            Optional<Projeto> projetoExistenteOptional =
                    projetoRepository.findByNumero(projeto.getNumero());

            if (projetoExistenteOptional.isPresent() && !projetoExistenteOptional.get().getId().equals(projetoID)) {
                return ResponseEntity.badRequest().body("O número já está em uso.");
            }

            BeanUtils.copyProperties(projeto, projetoCurrent, "id", "aditivos", "dataAdicionado",
                    "dataAtualizado", "arquivo");
            projetoCurrent.preUpdate();

            projetoRepository.save(projetoCurrent);
            return ResponseEntity.ok("Dados do projeto atualizados.");
        } else {
            return ResponseEntity.badRequest().body("Dados inválidos.");
        }
    }

    @PutMapping("/arquivo/{projetoID}")
    public ResponseEntity<?> updateArquivo(
            @PathVariable String projetoID,
            @RequestParam(value = "arquivo") MultipartFile arquivo) {
        Optional<Projeto> projetoOptional = projetoRepository.findById(projetoID);

        if (projetoOptional.isPresent()) {
            Projeto projetoCurrent = projetoOptional.get();

            if (arquivo != null && !arquivo.isEmpty()) {
                try {
                    byte[] arquivoBytes = arquivo.getBytes();

                    if (projetoCurrent.getArquivo() == null) {
                        projetoCurrent.setArquivo(new Arquivo());
                    }
                    projetoCurrent.getArquivo().setNome(arquivo.getOriginalFilename());
                    projetoCurrent.getArquivo().setFormato(arquivo.getContentType());
                    projetoCurrent.getArquivo().setDados(arquivoBytes);
                } catch (IOException e) {
                    return ResponseEntity.badRequest().body("Erro ao processar o arquivo.");
                }
            }
            projetoCurrent.preUpdate();
            projetoRepository.save(projetoCurrent);
            return ResponseEntity.ok("Arquivo atualizado.");
        } else {
            return ResponseEntity.badRequest().body("Projeto não encontrado.");
        }
    }

    @PutMapping("/aditivo/{projetoID}/{aditivoID}")
    public ResponseEntity<?> updateAditivo(@PathVariable String projetoID,
                                           @PathVariable String aditivoID) {
        Optional<Projeto> projetoOptional = projetoRepository.findById(projetoID);

        if (projetoOptional.isPresent()) {
            Projeto projeto = projetoOptional.get();
            List<Aditivo> aditivos = projeto.getAditivos();

            if (aditivos != null) {
                Optional<Aditivo> aditivoOptional = aditivos.stream()
                        .filter(aditivo -> aditivo != null && aditivo.getId() != null && aditivo.getId().equals(aditivoID))
                        .findFirst();

                if (aditivoOptional.isPresent()) {
                    return ResponseEntity.ok("Aditivo já existe no projeto.");
                } else {
                    if (aditivoID != null) {
                        Optional<Aditivo> aditivoEncontrado = aditivoRepository.findById(aditivoID);

                        if (aditivoEncontrado.isPresent()) {
                            Aditivo aditivoNovo = aditivoEncontrado.get();
                            aditivoNovo.preUpdate();
                            aditivos.add(aditivoNovo);
                            projeto.preUpdate();
                            projetoRepository.save(projeto);
                            return ResponseEntity.ok("Aditivo adicionado com sucesso.");
                        } else {
                            return ResponseEntity.badRequest().body("Aditivo não encontrado.");
                        }
                    } else {
                        return ResponseEntity.badRequest().body("ID do aditivo inválido.");
                    }
                }
            }
        }

        return ResponseEntity.badRequest().body("Projeto não encontrado.");
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@RequestBody Projeto projeto) {
        if (projetoRepository.findByNumero(projeto.getNumero()).isPresent()) {
            return ResponseEntity.badRequest().body("Projeto já existe.");
        } else {
            projeto.prePersist();
            projetoRepository.save(projeto);

            return ResponseEntity.ok("Projeto cadastrado com sucesso.");
        }
    }
}
