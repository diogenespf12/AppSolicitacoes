package com.automasul.apiautomasul.model;

public enum TipoContrato {
    FORNECEDOR,
    FUNCIONARIO,
    CLIENTE
}
