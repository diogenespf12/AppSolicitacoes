package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.FerramentaEquipamento;
import com.automasul.apiautomasul.model.Status;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.FerramentaEquipamentoRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/ferramentaequipamento")
public class FerramentaEquipamentoController {
    @Autowired
    private FerramentaEquipamentoRepository ferramentaEquipamentoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<FerramentaEquipamento> ferramentaEquipamentos = ferramentaEquipamentoRepository.findAll();

        if (ferramentaEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhuma ferramenta e ou equipamento encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentos);
    }

    @GetMapping("/ferramenta/")
    private ResponseEntity<?> findAllFerramenta() {
        List<FerramentaEquipamento> ferramentaEquipamentos =
                ferramentaEquipamentoRepository.findAllByFerramenta(Boolean.TRUE);

        if (ferramentaEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhuma ferramenta encontrada.");
        }

        return ResponseEntity.ok(ferramentaEquipamentos);
    }

    @GetMapping("/equipamento/")
    private ResponseEntity<?> findAllEquipamento() {
        List<FerramentaEquipamento> ferramentaEquipamentos =
                ferramentaEquipamentoRepository.findAllByFerramenta(Boolean.FALSE);

        if (ferramentaEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhum equipamento encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentos);
    }

    @GetMapping("/{ferramentaEquipamentoID}")
    private ResponseEntity<?> findByID(@PathVariable String ferramentaEquipamentoID){
        Optional<FerramentaEquipamento> ferramentaEquipamentoOptional =
                ferramentaEquipamentoRepository.findById(ferramentaEquipamentoID);

        if (ferramentaEquipamentoOptional.isEmpty()) {
            return ResponseEntity.ok("Ferramenta e ou equipamento não encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentoOptional.get());
    }

    @GetMapping("/ferramenta/numero/{numero}")
    private ResponseEntity<?> findByNumero(@PathVariable String numero){
        Optional<FerramentaEquipamento> ferramentaEquipamentoOptional =
                ferramentaEquipamentoRepository.findByAuxFerramentaNumero(numero);

        if (ferramentaEquipamentoOptional.isEmpty()) {
            return ResponseEntity.ok("Ferramenta não encontrada.");
        }

        return ResponseEntity.ok(ferramentaEquipamentoOptional.get());
    }

    @GetMapping("/ferramenta/codigo/{codigo}")
    private ResponseEntity<?> findByCodigoFerramenta(@PathVariable String codigo){
        Optional<FerramentaEquipamento> ferramentaEquipamentoOptional =
                ferramentaEquipamentoRepository.findByFerramentaAndCodigo(Boolean.TRUE, codigo);

        if (ferramentaEquipamentoOptional.isEmpty()) {
            return ResponseEntity.ok("Ferramenta não encontrada.");
        }

        return ResponseEntity.ok(ferramentaEquipamentoOptional.get());
    }

    @GetMapping("/equipamento/codigo/{codigo}")
    private ResponseEntity<?> findByCodigoEquipamento(@PathVariable String codigo){
        Optional<FerramentaEquipamento> ferramentaEquipamentoOptional =
                ferramentaEquipamentoRepository.findByFerramentaAndCodigo(Boolean.FALSE, codigo);

        if (ferramentaEquipamentoOptional.isEmpty()) {
            return ResponseEntity.ok("Equipamento não encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentoOptional.get());
    }

    @GetMapping("/status/{status}")
    private ResponseEntity<?> findByStatus(@PathVariable Status status){
        List<FerramentaEquipamento> ferramentaEquipamentos =
                ferramentaEquipamentoRepository.findAllByStatus(status);

        if (ferramentaEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + status.name() + " " +
                    "em ferramenta ou equipamento foi encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentos);
    }

    @GetMapping("/ferramenta/status/{status}")
    private ResponseEntity<?> findByStatusFerramenta(@PathVariable Status status){
        List<FerramentaEquipamento> ferramentaEquipamentos =
                ferramentaEquipamentoRepository.findAllByFerramentaAndStatus(Boolean.TRUE, status);

        if (ferramentaEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + status.name() + " " +
                    "em ferramenta foi encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentos);
    }

    @GetMapping("/equipamento/status/{status}")
    private ResponseEntity<?> findByStatusEquipamento(@PathVariable Status status){
        List<FerramentaEquipamento> ferramentaEquipamentos =
                ferramentaEquipamentoRepository.findAllByFerramentaAndStatus(Boolean.FALSE, status);

        if (ferramentaEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + status.name() + " " +
                    "em equipamento foi encontrado.");
        }

        return ResponseEntity.ok(ferramentaEquipamentos);
    }

    @PutMapping("/{ferramentaequipamentoID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String ferramentaequipamentoID,
            @PathVariable String usuarioID,
            @RequestBody FerramentaEquipamento ferramentaEquipamento) {
        Optional<FerramentaEquipamento> ferramentaEquipamentoOptional =
                ferramentaEquipamentoRepository.findById(ferramentaequipamentoID);

        if (ferramentaEquipamentoOptional.isPresent()) {
            FerramentaEquipamento ferramentaEquipamentoCurrent = ferramentaEquipamentoOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()) {
                Usuario usuarioCurrent = usuarioOptional.get();

                Optional<FerramentaEquipamento> ferramentaExistenteOptional =
                        ferramentaEquipamentoRepository.findByCodigo(ferramentaEquipamento.getCodigo());

                if (ferramentaExistenteOptional.isPresent() && !ferramentaExistenteOptional.get().getId().equals(ferramentaequipamentoID)) {
                    return ResponseEntity.badRequest().body("O código já está em uso.");
                } else if (ferramentaEquipamento.getAuxFerramenta() != null && ferramentaEquipamento.getAuxFerramenta().getNumero() != null) {
                    Optional<FerramentaEquipamento> ferramentaNumeroExistenteOptional =
                            ferramentaEquipamentoRepository.findByAuxFerramentaNumero(ferramentaEquipamento.getAuxFerramenta().getNumero());

                    if (ferramentaNumeroExistenteOptional.isPresent() && !ferramentaNumeroExistenteOptional.get().getId().equals(ferramentaequipamentoID)) {
                        return ResponseEntity.badRequest().body("O número da ferramenta já está em uso.");
                    }
                }

                BeanUtils.copyProperties(ferramentaEquipamento, ferramentaEquipamentoCurrent,
                        "id", "controleUsuario");

                ferramentaEquipamentoCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                ferramentaEquipamentoRepository.save(ferramentaEquipamentoCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }
    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody FerramentaEquipamento ferramentaEquipamento) {
        Optional<FerramentaEquipamento> ferramentaExistenteOptional =
                ferramentaEquipamentoRepository.findByFerramentaAndCodigo(ferramentaEquipamento.getFerramenta(), ferramentaEquipamento.getCodigo());

        if (ferramentaExistenteOptional.isPresent()) {
            return ResponseEntity.badRequest().body("Ferramenta e ou equipamento já existe.");
        } else if (ferramentaEquipamento.getAuxFerramenta() != null && ferramentaEquipamento.getAuxFerramenta().getNumero() != null) {
            Optional<FerramentaEquipamento> ferramentaNumeroExistenteOptional =
                    ferramentaEquipamentoRepository.findByAuxFerramentaNumero(ferramentaEquipamento.getAuxFerramenta().getNumero());

            if (ferramentaNumeroExistenteOptional.isPresent()) {
                return ResponseEntity.badRequest().body("O número da ferramenta já está em uso.");
            }
        }

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            ferramentaEquipamento.getControleUsuario().prePersist(usuarioCurrent.getId());
            ferramentaEquipamentoRepository.save(ferramentaEquipamento);

            return ResponseEntity.ok("Ferramenta e ou equipamento cadastrado com sucesso.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

}
