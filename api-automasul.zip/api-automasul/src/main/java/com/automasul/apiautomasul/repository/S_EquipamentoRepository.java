package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.S_Equipamento;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface S_EquipamentoRepository extends MongoRepository<S_Equipamento, String> {
}
