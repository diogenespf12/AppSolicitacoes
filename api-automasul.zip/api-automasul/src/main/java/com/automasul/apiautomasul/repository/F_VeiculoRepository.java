package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.F_Veiculo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface F_VeiculoRepository extends MongoRepository<F_Veiculo, String> {
}
