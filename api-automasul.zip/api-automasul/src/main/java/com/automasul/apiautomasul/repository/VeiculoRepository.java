package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.Status;
import com.automasul.apiautomasul.model.Veiculo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VeiculoRepository extends MongoRepository<Veiculo, String> {
    Optional<Veiculo> findByPlaca(String placa);
    List<Veiculo> findAllByStatus(Status status);
}
