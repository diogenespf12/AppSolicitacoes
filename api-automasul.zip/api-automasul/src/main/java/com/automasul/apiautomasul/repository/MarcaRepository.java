package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.Finalidade;
import com.automasul.apiautomasul.model.Marca;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MarcaRepository extends MongoRepository<Marca, String> {
    Optional<Marca> findByNome(String nome);
    List<Marca> findAllByFinalidade(Finalidade finalidade);
    Optional<Marca> findByNomeAndFinalidade(String nome, Finalidade finalidade);
}
