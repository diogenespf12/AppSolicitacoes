package com.automasul.apiautomasul.model;

public enum Finalidade {
    FERRAMENTA,
    EQUIPAMENTO,
    VEICULO
}
