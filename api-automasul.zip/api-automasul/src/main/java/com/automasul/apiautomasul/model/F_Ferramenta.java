package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class F_Ferramenta extends Feedback{
    @DBRef
    private List<FerramentaEquipamento> ferramentas;
    private String nomeResponsavel;
    private String localRetirada;
    private String localDevolucao;
}
