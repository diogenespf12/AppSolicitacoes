package com.automasul.apiautomasul.dto;

public record LoginResponseDTO(String token) {
}
