package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Veiculo {
    @Id
    @EqualsAndHashCode.Include
    private String id;
    private String placa;
    private String nome;
    @DBRef
    private Tipo tipo;
    @DBRef
    private Marca marca;
    private Status status;
    private ControleUsuario controleUsuario = new ControleUsuario();
    private ControleStatus controleStatus;
    private String observacao;
}
