package com.automasul.apiautomasul.dto;

import com.automasul.apiautomasul.model.Contato;
import com.automasul.apiautomasul.model.Role;

public record RegisterDTO(String login, String senha, Role role, Contato contato) {

}
