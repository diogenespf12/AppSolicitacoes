package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.F_Hospedagem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface F_HospedagemRepository extends MongoRepository<F_Hospedagem, String> {
}
