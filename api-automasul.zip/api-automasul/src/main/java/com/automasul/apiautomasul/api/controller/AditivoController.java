package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.Aditivo;
import com.automasul.apiautomasul.model.Arquivo;
import com.automasul.apiautomasul.model.TipoContrato;
import com.automasul.apiautomasul.repository.AditivoRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/aditivo")
public class AditivoController {
    @Autowired
    private AditivoRepository aditivoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll(){
        List<Aditivo> aditivos = aditivoRepository.findAll();

        if (aditivos.isEmpty()){
            return ResponseEntity.ok("Nenhum aditivo de contrato encontrado.");
        }

        return ResponseEntity.ok(aditivos);
    }

    @GetMapping("/{aditivoID}")
    private ResponseEntity<?> findById(@PathVariable String aditivoID){
        Optional<Aditivo> aditivoOptional = aditivoRepository.findById(aditivoID);

        if (aditivoOptional.isEmpty()){
            return ResponseEntity.ok("Nenhum aditivo de contrato encontrado.");
        }

        return ResponseEntity.ok(aditivoOptional.get());
    }

    @GetMapping("/tipocontrato/{tipoContrato}")
    private ResponseEntity<?> findByTipoContrato(@PathVariable TipoContrato tipoContrato){
        List<Aditivo> aditivos = aditivoRepository.findAllByTipoContrato(tipoContrato);

        if (aditivos.isEmpty()) {
            return ResponseEntity.ok("Nenhum tipo de contrato: "
                    + tipoContrato.name()
                    + " em aditivo foi encontrado.");
        }

        return ResponseEntity.ok(aditivos);
    }

    @GetMapping("/ativo/{ativo}")
    private ResponseEntity<?> findByAtivo(@PathVariable Boolean ativo){
        List<Aditivo> aditivos = aditivoRepository.findAllByAtivo(ativo);

        if (aditivos.isEmpty()) {
            String mensagem;
            if (ativo) {
                mensagem = "Nenhum contrato ativo em aditivo foi encontrado.";
            } else {
                mensagem = "Nenhum contrato inativo em aditivo foi encontrado.";
            }
            return ResponseEntity.ok(mensagem);
        }

        return ResponseEntity.ok(aditivos);
    }

    @GetMapping("/arquivo/conteudo/{aditivoID}")
    public ResponseEntity<?> getArquivoConteudo(@PathVariable String aditivoID) {
        Optional<Aditivo> aditivoOptional = aditivoRepository.findById(aditivoID);

        if (aditivoOptional.isPresent()) {
            Aditivo aditivo = aditivoOptional.get();
            Arquivo arquivo = aditivo.getArquivo();

            if (arquivo != null && arquivo.getDados() != null && arquivo.getDados().length > 0) {
                String conteudo = new String(arquivo.getDados(), StandardCharsets.UTF_8);
                return ResponseEntity.ok(conteudo);
            } else {
                return ResponseEntity.ok("Não há conteúdo no arquivo.");
            }
        } else {
            return ResponseEntity.badRequest().body("Aditivo não encontrado.");
        }
    }

    @PutMapping("/{aditivoID}")
    public ResponseEntity<?> updateAditivo(
            @PathVariable String aditivoID,
            @RequestBody Aditivo aditivo) {
        Optional<Aditivo> aditivoOptional = aditivoRepository.findById(aditivoID);

        if (aditivoOptional.isPresent()) {
            Aditivo aditivoCurrent = aditivoOptional.get();

            BeanUtils.copyProperties(aditivo, aditivoCurrent, "id", "dataAdicionado",
                    "dataAtualizado", "arquivo");
            aditivoCurrent.preUpdate();

            aditivoRepository.save(aditivoCurrent);
            return ResponseEntity.ok("Dados do aditivo atualizados.");
        } else {
            return ResponseEntity.badRequest().body("Dados inválidos.");
        }
    }

    @PutMapping("/arquivo/{aditivoID}")
    public ResponseEntity<?> updateArquivo(
            @PathVariable String aditivoID,
            @RequestParam(value = "arquivo") MultipartFile arquivo) {
        Optional<Aditivo> aditivoOptional = aditivoRepository.findById(aditivoID);

        if (aditivoOptional.isPresent()) {
            Aditivo aditivoCurrent = aditivoOptional.get();

            if (arquivo != null && !arquivo.isEmpty()) {
                try {
                    byte[] arquivoBytes = arquivo.getBytes();

                    if (aditivoCurrent.getArquivo() == null) {
                        aditivoCurrent.setArquivo(new Arquivo());
                    }
                    aditivoCurrent.getArquivo().setNome(arquivo.getOriginalFilename());
                    aditivoCurrent.getArquivo().setFormato(arquivo.getContentType());
                    aditivoCurrent.getArquivo().setDados(arquivoBytes);
                } catch (IOException e) {
                    return ResponseEntity.badRequest().body("Erro ao processar o arquivo.");
                }
            }
            aditivoCurrent.preUpdate();
            aditivoRepository.save(aditivoCurrent);
            return ResponseEntity.ok("Arquivo atualizado.");
        } else {
            return ResponseEntity.badRequest().body("Aditivo não encontrado.");
        }
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@RequestBody Aditivo aditivo) {
        aditivo.prePersist();
        try {
            aditivoRepository.save(aditivo);
            return ResponseEntity.ok("Aditivo cadastrado com sucesso.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Falha ao cadastrar o aditivo.");
        }
    }

}
