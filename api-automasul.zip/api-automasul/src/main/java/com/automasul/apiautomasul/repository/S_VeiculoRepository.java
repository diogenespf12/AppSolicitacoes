package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.S_Veiculo;
import com.automasul.apiautomasul.model.StatusSolicitacao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface S_VeiculoRepository extends MongoRepository<S_Veiculo, String> {
    List<S_Veiculo> findAllByStatusSolicitacao(StatusSolicitacao statusSolicitacao);
}
