package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.Role;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<Usuario> usuarios = usuarioRepository.findAll();

        if (usuarios.isEmpty()) {
            return ResponseEntity.ok("Nenhum usuario encontrado.");
        }

        return ResponseEntity.ok(usuarios);
    }

    @GetMapping("/{usuarioID}")
    private ResponseEntity<?> findByID(@PathVariable String usuarioID){
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isEmpty()) {
            return ResponseEntity.ok("Usuário não encontrado.");
        }

        return ResponseEntity.ok(usuarioOptional.get());
    }

    @GetMapping("/login/{login}")
    private ResponseEntity<?> findByLogin(@PathVariable String login){
        Optional<Usuario> usuarioOptional = usuarioRepository.findByLogin(login);

        if (usuarioOptional.isEmpty()) {
            return ResponseEntity.ok("Usuário não encontrado.");
        }

        return ResponseEntity.ok(usuarioOptional.get());
    }

    @GetMapping("/role/{role}")
    private ResponseEntity<?> findByRole(@PathVariable Role role){
        List<Usuario> usuarios = usuarioRepository.findAllByRole(role);

        if (usuarios.isEmpty()) {
            return ResponseEntity.ok("Nenhum usuario encontrado.");
        }

        return ResponseEntity.ok(usuarios);
    }

    @PutMapping("/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String usuarioID,
            @RequestBody Usuario usuario) {
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            Optional<Usuario> usuarioExistenteOptional = usuarioRepository.findByLogin(usuario.getLogin());

            if (usuarioExistenteOptional.isPresent() && !usuarioExistenteOptional.get().getId().equals(usuarioID)) {
                return ResponseEntity.badRequest().body("O login já está em uso.");
            }

            //if (!usuario.getSenha().equals(usuarioCurrent.getSenha())) {
            //    String senhaCriptografada = new BCryptPasswordEncoder().encode(usuario.getSenha());
            //    usuario.setSenha(senhaCriptografada);
            //}

            BeanUtils.copyProperties(usuario, usuarioCurrent, "id");

            usuarioRepository.save(usuarioCurrent);
            return ResponseEntity.ok("Dados atualizados.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@RequestBody Usuario usuario) {
        if (usuarioRepository.findByLogin(usuario.getLogin()).isPresent()) {
            return ResponseEntity.badRequest().body("Usuário já existe.");
        }
        else {
            //String senhaCriptografada = new BCryptPasswordEncoder().encode(usuario.getSenha());
            //usuario.setSenha(senhaCriptografada);
            usuarioRepository.save(usuario);
            return ResponseEntity.ok("Conta criada com sucesso.");
        }
    }
}
