package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuxFerramenta {
    private String numero;
    private Integer afericaoDias;
    private LocalDate dataUltimaAfericao;
    private String medida;
}
