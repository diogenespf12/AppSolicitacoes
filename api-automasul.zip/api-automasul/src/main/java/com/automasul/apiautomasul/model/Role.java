package com.automasul.apiautomasul.model;

public enum Role {
    ADMINISTRATIVO ("ADMINISTRATIVO"),
    SUPRIMENTOS ("SUPRIMENTOS"),
    GESTOR ("GESTOR"),
    REQUISITANTE ("REQUISITANTE");

    private String role;

    Role (String role){
        this.role = role;
    }

    public String getRole(){ return role; }
}
