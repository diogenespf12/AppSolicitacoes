package com.automasul.apiautomasul.model;

public enum Role {
    ADMINISTRATIVO,
    SUPRIMENTOS,
    GESTOR,
    REQUISITANTE
}
