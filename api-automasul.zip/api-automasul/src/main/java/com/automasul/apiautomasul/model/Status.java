package com.automasul.apiautomasul.model;

public enum Status {
    INDEFINIDO,
    EM_MANUTENCAO,
    INDISPONIVEL,
    EM_USO,
    DISPONIVEL
}
