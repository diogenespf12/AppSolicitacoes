package com.automasul.apiautomasul.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Usuario implements UserDetails {
    @Id
    @EqualsAndHashCode.Include
    private String id;
    private Role role;
    private String login;
    private String senha;
    private Contato contato;
    public Usuario(Role role, String login, String senha, Contato contato){
        this.login = login;
        this.senha = senha;
        this.role = role;
        this.contato = contato;
    }
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (this.role == Role.ADMINISTRATIVO){
            return List.of(
                    new SimpleGrantedAuthority("ROLE_ADMINISTRATIVO"),
                    new SimpleGrantedAuthority("ROLE_USER")
            );
        } else if (this.role == Role.SUPRIMENTOS) {
            return List.of(
                    new SimpleGrantedAuthority("ROLE_SUPRIMENTOS"),
                    new SimpleGrantedAuthority("ROLE_USER")
            );
        } else if (this.role == Role.GESTOR) {
            return List.of(
                    new SimpleGrantedAuthority("ROLE_GESTOR"),
                    new SimpleGrantedAuthority("ROLE_USER")
            );
        } else if (this.role == Role.REQUISITANTE){
            return List.of(
                    new SimpleGrantedAuthority("ROLE_REQUISITANTE"),
                    new SimpleGrantedAuthority("ROLE_USER")
            );
        }
        else {
            return List.of(new SimpleGrantedAuthority("ROLE_USER"));
        }
    }

    @Override
    public String getPassword() {
        return this.senha;
    }

    @Override
    public String getUsername() {
        return this.login;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
