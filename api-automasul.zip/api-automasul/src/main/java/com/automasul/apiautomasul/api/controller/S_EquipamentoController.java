package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.S_Equipamento;
import com.automasul.apiautomasul.model.StatusSolicitacao;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.S_EquipamentoRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/sequipamento")
public class S_EquipamentoController {
    @Autowired
    private S_EquipamentoRepository sEquipamentoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<S_Equipamento> sEquipamentos = sEquipamentoRepository.findAll();

        if (sEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhuma solicitação de equipamento encontrada.");
        }

        return ResponseEntity.ok(sEquipamentos);
    }

    @GetMapping("/{sequipamentoID}")
    private ResponseEntity<?> findByID(@PathVariable String sequipamentoID){
        Optional<S_Equipamento> sEquipamentoOptional =
                sEquipamentoRepository.findById(sequipamentoID);

        if (sEquipamentoOptional.isEmpty()) {
            return ResponseEntity.ok("Solicitação de equipamento não encontrada.");
        }

        return ResponseEntity.ok(sEquipamentoOptional.get());
    }

    @GetMapping("/statussolicitacao/{statusSolicitacao}")
    private ResponseEntity<?> findByStatus(@PathVariable StatusSolicitacao statusSolicitacao){
        List<S_Equipamento> sEquipamentos =
                sEquipamentoRepository.findAllByStatusSolicitacao(statusSolicitacao);

        if (sEquipamentos.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + statusSolicitacao.name() + " " +
                    "em solicitação de equipamento encontrado.");
        }

        return ResponseEntity.ok(sEquipamentos);
    }

    @PutMapping("/{sequipamentoID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String sequipamentoID,
            @PathVariable String usuarioID,
            @RequestBody S_Equipamento sEquipamento) {
        Optional<S_Equipamento> sEquipamentoOptional =
                sEquipamentoRepository.findById(sequipamentoID);

        if (sEquipamentoOptional.isPresent()) {
            S_Equipamento sEquipamentoCurrent = sEquipamentoOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()) {
                Usuario usuarioCurrent = usuarioOptional.get();

                BeanUtils.copyProperties(sEquipamento, sEquipamentoCurrent,
                        "id", "projeto", "controleUsuario",
                        "equipamentos", "proprio", "dataInicio", "dataFim", "descricaoUso");

                sEquipamentoCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                sEquipamentoRepository.save(sEquipamentoCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody S_Equipamento sEquipamento) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            sEquipamento.getControleUsuario().prePersist(usuarioCurrent.getId());

            sEquipamentoRepository.save(sEquipamento);

            return ResponseEntity.ok("Solicitação para equipamento cadastrada com sucesso.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }
}
