package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public abstract class Solicitacao {
    @Id
    @EqualsAndHashCode.Include
    private String id;
    @DBRef
    private Projeto projeto;
    private StatusSolicitacao statusSolicitacao;
    private ControleUsuario controleUsuario = new ControleUsuario();
}

