package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class S_Veiculo extends Solicitacao{
    private String destino;
    @DBRef
    private Tipo tipo;
    private LocalDate saida;
    private LocalDate retorno;
    private List<Pessoa> passageiros;
    private Integer qtdPassageiros = 1;

    public void prePersist(List<Pessoa> passageiros) {
        if (passageiros != null && !passageiros.isEmpty()) {
            this.qtdPassageiros = passageiros.size();
        }
    }
}
