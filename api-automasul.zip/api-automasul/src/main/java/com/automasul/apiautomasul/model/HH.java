package com.automasul.apiautomasul.model;

public enum HH {
    NORMAL,
    HH_50,
    HH_100,
    NENHUMA
}
