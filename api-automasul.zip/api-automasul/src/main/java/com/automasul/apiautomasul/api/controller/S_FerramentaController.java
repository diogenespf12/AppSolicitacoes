package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.S_Ferramenta;
import com.automasul.apiautomasul.model.StatusSolicitacao;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.S_FerramentaRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/sferramenta")
public class S_FerramentaController {
    @Autowired
    private S_FerramentaRepository sFerramentaRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<S_Ferramenta> sFerramentas = sFerramentaRepository.findAll();

        if (sFerramentas.isEmpty()) {
            return ResponseEntity.ok("Nenhuma solicitação de ferramenta encontrada.");
        }

        return ResponseEntity.ok(sFerramentas);
    }

    @GetMapping("/{sferramentaID}")
    private ResponseEntity<?> findByID(@PathVariable String sferramentaID){
        Optional<S_Ferramenta> sFerramentaOptional =
                sFerramentaRepository.findById(sferramentaID);

        if (sFerramentaOptional.isEmpty()) {
            return ResponseEntity.ok("Solicitação de ferramenta não encontrada.");
        }

        return ResponseEntity.ok(sFerramentaOptional.get());
    }

    @GetMapping("/statussolicitacao/{statusSolicitacao}")
    private ResponseEntity<?> findByStatus(@PathVariable StatusSolicitacao statusSolicitacao){
        List<S_Ferramenta> sFerramentas =
                sFerramentaRepository.findAllByStatusSolicitacao(statusSolicitacao);

        if (sFerramentas.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + statusSolicitacao.name() + " " +
                    "em solicitação de ferramenta encontrado.");
        }

        return ResponseEntity.ok(sFerramentas);
    }

    @PutMapping("/{sferramentaID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String sferramentaID,
            @PathVariable String usuarioID,
            @RequestBody S_Ferramenta sFerramenta) {
        Optional<S_Ferramenta> sFerramentaOptional =
                sFerramentaRepository.findById(sferramentaID);

        if (sFerramentaOptional.isPresent()) {
            S_Ferramenta sFerramentaCurrent = sFerramentaOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()) {
                Usuario usuarioCurrent = usuarioOptional.get();

                BeanUtils.copyProperties(sFerramenta, sFerramentaCurrent,
                        "id", "projeto", "controleUsuario",
                        "ferramentas", "nomeResponsavel");

                sFerramentaCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                sFerramentaRepository.save(sFerramentaCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody S_Ferramenta sFerramenta) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            sFerramenta.getControleUsuario().prePersist(usuarioCurrent.getId());

            sFerramentaRepository.save(sFerramenta);

            return ResponseEntity.ok("Solicitação para ferramenta cadastrada com sucesso.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }
}
