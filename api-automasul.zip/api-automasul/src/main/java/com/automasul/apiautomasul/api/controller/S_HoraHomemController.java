package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.S_HoraHomem;
import com.automasul.apiautomasul.model.StatusSolicitacao;
import com.automasul.apiautomasul.model.Usuario;
import com.automasul.apiautomasul.repository.S_HoraHomemRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/shorahomem")
public class S_HoraHomemController {
    @Autowired
    private S_HoraHomemRepository sHoraHomemRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<S_HoraHomem> sHoraHomems = sHoraHomemRepository.findAll();

        if (sHoraHomems.isEmpty()) {
            return ResponseEntity.ok("Nenhuma solicitação de hora-homem encontrada.");
        }

        return ResponseEntity.ok(sHoraHomems);
    }

    @GetMapping("/{shorahomemID}")
    private ResponseEntity<?> findByID(@PathVariable String shorahomemID){
        Optional<S_HoraHomem> sHoraHomemOptional =
                sHoraHomemRepository.findById(shorahomemID);

        if (sHoraHomemOptional.isEmpty()) {
            return ResponseEntity.ok("Solicitação de hora-homem não encontrada.");
        }

        return ResponseEntity.ok(sHoraHomemOptional.get());
    }

    @GetMapping("/statussolicitacao/{statusSolicitacao}")
    private ResponseEntity<?> findByStatus(@PathVariable StatusSolicitacao statusSolicitacao){
        List<S_HoraHomem> sHoraHomems =
                sHoraHomemRepository.findAllByStatusSolicitacao(statusSolicitacao);

        if (sHoraHomems.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + statusSolicitacao.name() + " " +
                    "em solicitação de hora-homem encontrado.");
        }

        return ResponseEntity.ok(sHoraHomems);
    }

    @PutMapping("/{shorahomemID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String shorahomemID,
            @PathVariable String usuarioID,
            @RequestBody S_HoraHomem sHoraHomem) {
        Optional<S_HoraHomem> sHoraHomemOptional =
                sHoraHomemRepository.findById(shorahomemID);

        if (sHoraHomemOptional.isPresent()) {
            S_HoraHomem sHoraHomemCurrent = sHoraHomemOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()) {
                Usuario usuarioCurrent = usuarioOptional.get();

                BeanUtils.copyProperties(sHoraHomem, sHoraHomemCurrent,
                        "id", "projeto", "controleUsuario",
                        "dataInicial", "dataFinal", "fornecedor", "funcao", "qtdContratado",
                        "descricaoServicos", "hospedagem", "alimentacao", "deslocamento", "hh",
                        "observacoes", "ferramentas", "descricaoFerramentas", "equipamentos",
                                "descricaoEquipamentos");

                sHoraHomemCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                sHoraHomemRepository.save(sHoraHomemCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody S_HoraHomem sHoraHomem) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            sHoraHomem.getControleUsuario().prePersist(usuarioCurrent.getId());

            sHoraHomemRepository.save(sHoraHomem);

            return ResponseEntity.ok("Solicitação para hora-homem cadastrada com sucesso.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }
}
