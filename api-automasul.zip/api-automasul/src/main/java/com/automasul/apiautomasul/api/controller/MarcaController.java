package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.Finalidade;
import com.automasul.apiautomasul.model.Marca;
import com.automasul.apiautomasul.repository.MarcaRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/marca")
public class MarcaController {
    @Autowired
    private MarcaRepository marcaRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<Marca> marcas = marcaRepository.findAll();

        if (marcas.isEmpty()) {
            return ResponseEntity.ok("Nenhuma marca encontrada.");
        }

        return ResponseEntity.ok(marcas);
    }

    @GetMapping("/finalidade/{finalidade}")
    private ResponseEntity<?> findAllFinalidade(@PathVariable Finalidade finalidade) {
        List<Marca> marcas = marcaRepository.findAllByFinalidade(finalidade);

        if (marcas.isEmpty()) {
            return ResponseEntity.ok("Nenhuma finalidade: " + finalidade.name() + " em marca foi encontrada.");
        }

        return ResponseEntity.ok(marcas);
    }

    @GetMapping("/{marcaID}")
    private ResponseEntity<?> findByID(@PathVariable String marcaID){
        Optional<Marca> marcaOptional = marcaRepository.findById(marcaID);

        if (marcaOptional.isEmpty()) {
            return ResponseEntity.ok("Marca não encontrada.");
        }

        return ResponseEntity.ok(marcaOptional.get());
    }

    @GetMapping("/nome/{nome}")
    private ResponseEntity<?> findByNome(@PathVariable String nome){
        Optional<Marca> marcaOptional = marcaRepository.findByNome(nome);

        if (marcaOptional.isEmpty()) {
            return ResponseEntity.ok("Marca não encontrada.");
        }

        return ResponseEntity.ok(marcaOptional.get());
    }

    @PutMapping("/{marcaID}")
    public ResponseEntity<?> update(
            @PathVariable String marcaID,
            @RequestBody Marca marca) {
        Optional<Marca> marcaOptional = marcaRepository.findById(marcaID);

        if (marcaOptional.isPresent()) {
            Marca marcaCurrent = marcaOptional.get();

            Optional<Marca> marcaExistenteOptional = marcaRepository.findByNomeAndFinalidade(marca.getNome(), marca.getFinalidade());

            if (marcaExistenteOptional.isPresent() && !marcaExistenteOptional.get().getId().equals(marcaID)) {
                return ResponseEntity.badRequest().body("O nome já está em uso para a mesma finalidade.");
            }

            BeanUtils.copyProperties(marca, marcaCurrent, "id");

            marcaRepository.save(marcaCurrent);
            return ResponseEntity.ok("Dados atualizados.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@RequestBody Marca marca) {
        Optional<Marca> marcaExistenteOptional = marcaRepository.findByNomeAndFinalidade(marca.getNome(), marca.getFinalidade());

        if (marcaExistenteOptional.isPresent()) {
            return ResponseEntity.badRequest().body("Já existe uma marca com o mesmo nome e finalidade.");
        } else {
            marcaRepository.save(marca);
            return ResponseEntity.ok("Marca cadastrada com sucesso.");
        }
    }

}
