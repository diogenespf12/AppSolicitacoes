package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.S_HoraHomem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface S_HoraHomemRepository extends MongoRepository<S_HoraHomem, String> {

}
