package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.S_HoraHomem;
import com.automasul.apiautomasul.model.StatusSolicitacao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface S_HoraHomemRepository extends MongoRepository<S_HoraHomem, String> {
    List<S_HoraHomem> findAllByStatusSolicitacao(StatusSolicitacao statusSolicitacao);
}
