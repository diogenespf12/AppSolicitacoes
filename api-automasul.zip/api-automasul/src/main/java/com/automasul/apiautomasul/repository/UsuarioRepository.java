package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.Role;
import com.automasul.apiautomasul.model.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends MongoRepository<Usuario, String> {
    Optional<Usuario> findByLogin(String login);
    List<Usuario> findAllByRole(Role role);
}






