package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.Finalidade;
import com.automasul.apiautomasul.model.Tipo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TipoRepository extends MongoRepository<Tipo, String> {
    Optional<Tipo> findByNome(String nome);
    List<Tipo> findAllByFinalidade(Finalidade finalidade);
    Optional<Tipo> findByNomeAndFinalidade(String nome, Finalidade finalidade);
}
