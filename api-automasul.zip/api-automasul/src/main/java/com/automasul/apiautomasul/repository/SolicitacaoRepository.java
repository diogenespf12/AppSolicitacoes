package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.Solicitacao;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface SolicitacaoRepository <T extends Solicitacao> extends MongoRepository<T, String> {
}

