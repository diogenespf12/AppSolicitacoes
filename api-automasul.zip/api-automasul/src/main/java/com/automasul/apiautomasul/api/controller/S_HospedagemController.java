package com.automasul.apiautomasul.api.controller;

import com.automasul.apiautomasul.model.*;
import com.automasul.apiautomasul.repository.S_HospedagemRepository;
import com.automasul.apiautomasul.repository.UsuarioRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/shospedagem")
public class S_HospedagemController {
    @Autowired
    private S_HospedagemRepository sHospedagemRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/")
    private ResponseEntity<?> findAll() {
        List<S_Hospedagem> sHospedagems = sHospedagemRepository.findAll();

        if (sHospedagems.isEmpty()) {
            return ResponseEntity.ok("Nenhuma solicitação de hospedagem encontrada.");
        }

        return ResponseEntity.ok(sHospedagems);
    }

    @GetMapping("/{shospedagemID}")
    private ResponseEntity<?> findByID(@PathVariable String shospedagemID){
        Optional<S_Hospedagem> sHospedagemOptional =
                sHospedagemRepository.findById(shospedagemID);

        if (sHospedagemOptional.isEmpty()) {
            return ResponseEntity.ok("Solicitação de hospedagem não encontrada.");
        }

        return ResponseEntity.ok(sHospedagemOptional.get());
    }

    @GetMapping("/statussolicitacao/{statusSolicitacao}")
    private ResponseEntity<?> findByStatus(@PathVariable StatusSolicitacao statusSolicitacao){
        List<S_Hospedagem> sHospedagems =
                sHospedagemRepository.findAllByStatusSolicitacao(statusSolicitacao);

        if (sHospedagems.isEmpty()) {
            return ResponseEntity.ok("Nenhum status: " + statusSolicitacao.name() + " " +
                    "em solicitação de hospedagem encontrado.");
        }

        return ResponseEntity.ok(sHospedagems);
    }

    @PutMapping("/{shospedagemID}/{usuarioID}")
    public ResponseEntity<?> update(
            @PathVariable String shospedagemID,
            @PathVariable String usuarioID,
            @RequestBody S_Hospedagem sHospedagem) {
        Optional<S_Hospedagem> sHospedagemOptional =
                sHospedagemRepository.findById(shospedagemID);

        if (sHospedagemOptional.isPresent()) {
            S_Hospedagem sHospedagemCurrent = sHospedagemOptional.get();

            Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

            if (usuarioOptional.isPresent()) {
                Usuario usuarioCurrent = usuarioOptional.get();

                BeanUtils.copyProperties(sHospedagem, sHospedagemCurrent,
                        "id", "projeto", "controleUsuario",
                        "cidade", "checkIn", "checkOut", "envolvidos");

                sHospedagemCurrent.getControleUsuario().preUpdate(usuarioCurrent.getId());

                sHospedagemRepository.save(sHospedagemCurrent);
                return ResponseEntity.ok("Dados atualizados.");
            } else {
                return ResponseEntity.badRequest().body("Dados inválidos.");
            }
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

    @PostMapping("/{usuarioID}")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> add(@PathVariable String usuarioID,
                                 @RequestBody S_Hospedagem sHospedagem) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioID);

        if (usuarioOptional.isPresent()) {
            Usuario usuarioCurrent = usuarioOptional.get();

            sHospedagem.getControleUsuario().prePersist(usuarioCurrent.getId());
            sHospedagemRepository.save(sHospedagem);

            return ResponseEntity.ok("Solicitação para hospedagem cadastrada com sucesso.");
        }

        return ResponseEntity.badRequest().body("Dados inválidos.");
    }

}
