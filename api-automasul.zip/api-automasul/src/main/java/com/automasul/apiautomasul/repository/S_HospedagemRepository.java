package com.automasul.apiautomasul.repository;

import com.automasul.apiautomasul.model.S_Hospedagem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface S_HospedagemRepository extends MongoRepository<S_Hospedagem, String> {
}
