package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class S_HoraHomem extends Solicitacao {
    private LocalDate dataInicial;
    private LocalDate dataFinal;
    private String fornecedor;
    private String funcao;
    private Integer qtdContratado;
    private String descricaoServicos;
    private Boolean hospedagem;
    private Boolean alimentacao;
    private Deslocamento deslocamento;
    private HH hh;
    private String observacoes;
    @DBRef
    private List<FerramentaEquipamento> ferramentas;
    private String descricaoFerramentas;
    @DBRef
    private List<FerramentaEquipamento> equipamentos;
    private String getDescricaoEquipamentos;
}
