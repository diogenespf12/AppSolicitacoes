package com.automasul.apiautomasul.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;


@Document
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class FerramentaEquipamento {
    @Id
    @EqualsAndHashCode.Include
    private String id;
    private String codigo;
    private String nome;
    private String observacao;
    @DBRef
    private Marca marca;
    @DBRef
    private Tipo tipo;
    private Status status;
    private Boolean ferramenta;
    private ControleStatus controleStatus;
    private ControleUsuario controleUsuario = new ControleUsuario();
    private AuxFerramenta auxFerramenta;
}
